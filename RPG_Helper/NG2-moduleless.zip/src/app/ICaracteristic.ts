export class ICaracteristic{
    value: number;
    max: number;
    name: string;
}