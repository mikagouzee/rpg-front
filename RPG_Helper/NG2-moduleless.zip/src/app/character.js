"use strict";
var Character = (function () {
    function Character() {
    }
    return Character;
}());
exports.Character = Character;
//# sourceMappingURL=character.js.map