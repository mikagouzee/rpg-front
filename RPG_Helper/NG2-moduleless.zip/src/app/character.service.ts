import { Injectable } from '@angular/core';
import { Headers, Http, Response} from '@angular/http';
import { Character } from './character';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class CharacterService{
    private charactersUrl = 'http://localhost:58225/api/getAll';

    constructor(private http:Http){}
    
    getCharacters(): Promise<Character[]>{
        alert("Getting Characters");
     
        // var my_data = this.http.get(this.charactersUrl)
        //                 .toPromise()
        //                 .then(response => response.json())

        // console.log("Resultat de l'appel = "+my_data);

        return this.http.get(this.charactersUrl)
            .toPromise()
            .then( (response => response.json() as Character[]) )
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any>{
        console.error('An error occurred', error);
        return Promise.reject(error.message ||error);
    }

    getCharacter(name:string):Promise<Character>{
        const url = `${this.charactersUrl}/${name}`;
        return this.http.get(url)
            .toPromise()
            .then(response => response.json().data as Character)
            .catch(this.handleError);
    }
}