"use strict";
var InMemoryDataService = (function () {
    function InMemoryDataService() {
    }
    InMemoryDataService.prototype.createDb = function () {
        var heroes = [
            { id: 11, name: 'mr Nice' },
            { id: 12, name: 'mr Nicer' },
            { id: 13, name: 'mr Nicest' },
            { id: 14, name: 'mr boom' },
            { id: 15, name: 'mr MAGNETO' },
            { id: 16, name: 'mr Chili' },
            { id: 17, name: 'mr NotNice' },
            { id: 18, name: 'mr Whuuut' }
        ];
        return { heroes: heroes };
    };
    return InMemoryDataService;
}());
exports.InMemoryDataService = InMemoryDataService;
//# sourceMappingURL=in-memory-data-service.js.map