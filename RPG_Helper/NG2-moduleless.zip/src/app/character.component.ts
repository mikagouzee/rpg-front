import { Component, OnInit} from '@angular/core';
import { Character } from './character';
import { CharacterService} from './character.service';
import { Router } from '@angular/router';

@Component({
    moduleId: module.id,

    selector: 'my-characters',

    template:`
    <h2>My characters</h2>
    <ul>
    <li *ngFor="let charac of characters">
        {{charac.characterName}}
    </li>
    </ul>
    `,
    providers:[CharacterService]

})

export class CharacterComponent implements OnInit{
    characters: Character[];

    constructor(private router: Router,
        private characterService: CharacterService){}

    ngOnInit():void{
        this.getCharacters();
    }

    getCharacters():void{
        this.characterService.getCharacters()
            .then(characters => this.characters = characters);
    }
}