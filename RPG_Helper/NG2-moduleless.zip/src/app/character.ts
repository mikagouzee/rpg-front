import { ICaracteristic } from './ICaracteristic';


export class Character{
    characterName: string;
    playerName: string;
    gameName: string;

    careerName: string;

    game: Object;

    baseAttr : ICaracteristic[];
    skills: ICaracteristic[];
    stats: ICaracteristic[];
    spendPoints: ICaracteristic[];

}