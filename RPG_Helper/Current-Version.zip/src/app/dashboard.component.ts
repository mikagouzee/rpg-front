import {Component, OnInit } from '@angular/core';
import {IGame } from './IGame';
import {Http} from '@angular/http';
import { GameService} from './game.service';

import 'rxjs/add/operator/toPromise';

@Component({
    moduleId:module.id,
    selector:'my-dashboard',
    //templateUrl: './dashboard.component.html',
    template:`<h3>Bienvenue dans RPG helper</h3>

<p>Selectionnez le jeu pour lequel vous souhaitez créer un personnage! </p>
<select [(ngModel)]="selectedGame"> 
    <option *ngFor="let game of games" >
    {{game.name}}</option>
</select>

<button (click)="create()">Commencer</button>`,
    providers: [GameService]
})

export class DashboardComponent implements OnInit{
    games:IGame[];
    selectedGame:IGame;
    //private gamesUrl = 'http://localhost:58225/api/games/getAll';

    ngOnInit():void{
        this.getGames();
    }

    constructor(private http:Http,
                private gameService:GameService){};

    getGames():void{
        this.gameService.getGames()
            .then(games => this.games = games)
        }

    create():void{
        console.log(this.selectedGame.name);
    }
}