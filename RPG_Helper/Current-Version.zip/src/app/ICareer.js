"use strict";
var ICareer = (function () {
    function ICareer() {
    }
    return ICareer;
}());
exports.ICareer = ICareer;
//# sourceMappingURL=ICareer.js.map