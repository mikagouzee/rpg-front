import { Injectable } from '@angular/core';
import { Headers, Http} from '@angular/http';
import { IGame } from './IGame';

@Injectable()
export class GameService{
    private gamesUrl = 'http://localhost:58225/api/games/getAll';
    
    constructor(private http:Http){}

    getGames():Promise<IGame[]>{
        return this.http.get(this.gamesUrl)
        .toPromise()
        .then(response => response.json() as IGame[]);
    }

    private handleError(error:any):Promise<any>{
        console.error("Error in Game Service : ", error);
        return Promise.reject(error.message|| error);
    }

}