import { ICaracteristic } from './ICaracteristic';

export class ICareer {
    name: string;
    jobSkills:ICaracteristic[];
}