"use strict";
var ICaracteristic = (function () {
    function ICaracteristic() {
    }
    return ICaracteristic;
}());
exports.ICaracteristic = ICaracteristic;
//# sourceMappingURL=ICaracteristic.js.map