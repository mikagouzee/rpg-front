"use strict";
var IGame = (function () {
    function IGame() {
    }
    return IGame;
}());
exports.IGame = IGame;
//# sourceMappingURL=IGame.js.map